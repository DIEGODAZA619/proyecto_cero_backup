<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['title_dialog1']='通知';    
    $lang['welcome_dialog1']='欢迎';
    $lang['title_dialog2']='我的積分';
    $lang['htleft_table']="剩下";
    $lang['htright_table']="正确的";
    $lang['httotal_table']="全部的";
    $lang['title_dialog3']="总积分";
    $lang['title_dialog4']="转移积分";
    $lang['profits']="利润";
    $lang['referral_bonus']="推荐奖金";
    $lang['rank']="秩";
    $lang['business_plan']="商业计划";
    $lang['my_network']="我的网络";
    $lang['sponsor']="赞助";
    $lang['title_dialog5']="总利润";
    $lang['progress']="进步";
    $lang['goal']="目标";
    $lang['title_dialog6']="计划时间";
    $lang['expire']="是时候让您的计划到期了";
    $lang['title_dialog7']="直接推荐";
    $lang['ht_name']="姓名";
    $lang['ht_email']="电子邮件";
    $lang['ht_plan']="计划";
    $lang['ht_phone']="电话";
    $lang['ht_date']="注册日期";
    $lang['title_dialog8']="推荐链接";
    $lang['button1']="复制链接";
    $lang['button2']="更改二进制密钥并控制网络上的每个用户";
    $lang['binary_key']="二进制密钥";
    $lang['ht_market']="市场";
    $lang['ht_sell']="多头/卖出";
    $lang['ht_id']="ID";
    $lang['ht_eth_quantity']="ETH 数量";
    $lang['ht_total_quantity']="全部的";



?>