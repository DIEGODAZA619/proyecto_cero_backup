<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['menu_item1']='Dashboard';
    $lang['menu_item2']='Plans';
    $lang['menu_item3']='Network';
    $lang['menu_item4']='Pending';
    $lang['menu_item5']='Binary Network';
    $lang['menu_item6']='Career Plans';
    $lang['menu_item7']='Finance';
    $lang['menu_item8']='Support/Ticket';
    $lang['menu_item9']='Profile';
    $lang['menu_item10']='Logout';

?>