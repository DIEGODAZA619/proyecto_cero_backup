<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['title_dialog1']='알림';
    $lang['welcome_dialog1']='어서 오십시오';
    $lang['title_dialog2']="내 포인트";
    $lang['htleft_table']="왼쪽";
    $lang['htright_table']="오른쪽";
    $lang['httotal_table']="합계";
    $lang['title_dialog3']="총 포인트";
    $lang['title_dialog4']="이전할 포인트";
    $lang['profits']="이익";
    $lang['referral_bonus']="추천 보너스";
    $lang['rank']="순위";
    $lang['business_plan']="순위";
    $lang['my_network']="내 네트워크";
    $lang['sponsor']="스폰서";
    $lang['title_dialog5']="총 이윤";
    $lang['progress']="진전";
    $lang['goal']="GOAL";
    $lang['title_dialog6']="계획 시간";
    $lang['expire']="요금제 만료 시간";
    $lang['title_dialog7']="직접 참조";
    $lang['ht_name']="이름";
    $lang['ht_email']="이메일";
    $lang['ht_plan']="수량";
    $lang['ht_phone']="전화";
    $lang['ht_date']="등록 날짜";
    $lang['title_dialog8']="권장 링크";
    $lang['button1']="링크 복사";
    $lang['button2']="네트워크의 모든 사용자를 제어합니다";
    $lang['binary_key']="바이너리 키";
    $lang['ht_market']="시장";
    $lang['ht_sell']="황소/매도";
    $lang['ht_id']="아이디";
    $lang['ht_eth_quantity']="ETH 수량";
    $lang['ht_total_quantity']="총";

?>