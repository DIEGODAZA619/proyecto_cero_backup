<?php 
    defined('BASEPATH')OR exit('No direct script access allowed');

    $lang['menu_item1']='대시보드';
    $lang['menu_item2']='계획';
    $lang['menu_item3']='네트워크';
    $lang['menu_item4']='보류 중';
    $lang['menu_item5']='바이너리 네트워크';
    $lang['menu_item6']='경력 계획';
    $lang['menu_item7']='금융';
    $lang['menu_item8']='지원/티켓';
    $lang['menu_item9']='프로필';
    $lang['menu_item10']='로그 아웃';

?>